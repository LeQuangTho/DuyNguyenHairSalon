
<?php $__env->startSection('body'); ?>
<link href="<?php echo e(asset('css/booking.css')); ?>" rel="stylesheet">
<script src="<?php echo e(URL::to('/')); ?>/resources/js/booking.js?ver=1"></script>
<script src="<?php echo e(asset('haircare/mobiscroll/mobiscroll.javascript.min.js')); ?>"></script>
<div style="height: 85px;background-color: #000;"></div>
<section class="hero-wrap" style="background-color: #eee;">
    <!-- <div class="overlay js-fullheight"></div> -->
    <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
            <div class="align-items-center" style="width: 500px;margin: auto;background-color: #fff;">
                <div id="content-step1">
                    <div class="title-top"><span>Đặt lịch cắt tóc</span></div>
                    <div class="info-booking">
                        <div class="title-item">1. Chọn dịch vụ và thời gian</div>
                        <div class="block-service">
                            <div class="title-iconleft">
                                <i class="icon-cut"></i>
                            </div>
                            <div class="box-text">
                                <span>Mời anh, chị chọn dịch vụ</span>
                            </div>
                            <div class="title-iconright">
                                <i class="icon-caret-right"></i>
                            </div>
                        </div>
                        <div class="list-service"> 
                      <!--   list item service -->
                        </div>
                        <div class="block-box">
                            <div class="block-time">
                                <div class="title-iconleft">
                                    <i class="icon-calendar"></i>
                                </div>
                                <div class="box-text select">
                                    <?php ($i=0); ?>
                                    <?php $__currentLoopData = $threeday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$i): ?>
                                            <span data-id="<?php echo e($k); ?>"><?php echo e($day); ?></span>
                                            <?php ($i++); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="title-iconright">
                                    <i class="icon-caret-right"></i>
                                </div>
                            </div>
                            <div class="box-dropdown">
                                <?php $__currentLoopData = $threeday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-action"><span data-day="<?php echo e($k); ?>"><?php echo e($day); ?></span></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="box-time">
                            <div class="swiper-container mySwiper-step1">
                                <div class="swiper-wrapper">
                                    
                                </div>
                            </div>
                            <div class="swiper-button-next button-next"></div>
                            <div class="swiper-button-prev button-prev"></div>
                        </div>
                    </div>
                    <div class="utilities">
                        <div>
                            <div class="title-item">2. Chọn tiện ích miễn phí</div>
                            <div class="box-content">
                                <?php $__currentLoopData = $ds_tienich; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item-free">
                                    <label class="control control--checkbox" style="font-size:15px;">
                                        <span><?php echo e($ti); ?></span>
                                        <input class="servicefree" name="servicefree" type="checkbox" value="<?php echo e($ti); ?>">
                                        <div class="control__indicator" style="top:0;height:25px;width:25px;"></div>
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div>
                            <div class="item-extenstion">
                                <div class="d-flex justify-content-between">
                                    <span>Yêu cầu tư vấn</span>
                                    <input name="consulting" type="checkbox" checked class="js-switch" data-color="#ffca4a" value="1"/>
                                </div>
                                <div class="content-ex">Anh đồng ý nghe thông tin về các chương trình bán hàng, khuyến mãi, giảm giá</div>
                            </div>
                            <hr>
                            <div class="item-extenstion">
                                <div class="d-flex justify-content-between">
                                    <span>Chụp hình sau khi cắt</span>
                                    <input name="photo" type="checkbox" checked class="js-switch" data-color="#ffca4a" value="1"/>
                                </div>
                                <div class="content-ex">Anh cho phép chụp hình lưu lại kiểu tóc, để lần sau không phải mô tả lại cho thợ khác</div>
                            </div>
                        </div>
                    </div>
                    <div class="choose-service"><button id="complete-booking">Hoàn tất</button></div>
                </div>
                <input type="hidden" id="dm-service" value="<?php echo e($dm_service); ?>">
                <input type="hidden" id="list-service" value="<?php echo e($gr_service); ?>">
                <input type="hidden" id="item-service" value="<?php echo e($item_service); ?>">
                <div id="content-step2">

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('LayoutWeb/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\myblog\resources\views/Web/Booking.blade.php ENDPATH**/ ?>
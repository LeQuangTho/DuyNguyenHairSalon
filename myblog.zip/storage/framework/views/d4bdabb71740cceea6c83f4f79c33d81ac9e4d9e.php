<link rel="stylesheet" href="<?php echo e(asset('css/store.css')); ?>"></link>

<?php $__env->startSection('body'); ?>
<div style="height: 85px;background-color: #000;"></div>
<div class="header-top">
    <div class="swiper-container SwiperBanner">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
        <img src="<?php echo e(asset('haircare/images/slideshow_2.jpg')); ?>" />
        </div>
        <div class="swiper-slide">
        <img src="<?php echo e(asset('haircare/images/slideshow_1.jpg')); ?>" />
        </div>
        <div class="swiper-slide">
        <img src="<?php echo e(asset('haircare/images/slideshow_3.jpg')); ?>" />
        </div>
        <div class="swiper-slide">
        <img src="<?php echo e(asset('haircare/images/slideshow_4.jpg')); ?>" />
        </div>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
    </div>
</div>
<div >
    <div id="main-content">
        <?php $__currentLoopData = $species_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="collections?sp=<?php echo e($sp->ID_SpeciesProduct); ?>" class="item-sp">
            <img src="<?php echo e(asset('haircare/images').'/'.$sp->Image_SpeciesProduct); ?>" alt="">
            <span><?php echo e($sp->Name_SpeciesProduct); ?></span>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="involve-content">
        <div class="container-fluid" style="height:500px">
            <div class="title-invole-store">
                <span class="text-title">Sản phẩm nổi bật</span>
                <span><a href="">Xem tất cả</a></span>
            </div>
            <div class="content-store">
                <div class="swiper-container SwiperStoreHot">
                    <div class="swiper-wrapper">
                        <?php for($i= 1;$i< 30; ++$i): ?>
                        <div class="swiper-slide">
                            <div class="owl-item">
                                <div class="item-info">
                                    <a href="#" class="team" title="Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML">
                                        <div class="img" style="height:250px;background-image: url(http://localhost:8081/myblog/public/haircare/images/stylist-<?php echo e(rand(1,5)); ?>.jpg);"></div>
                                        <span>Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML</span>
                                        <span>237,000₫</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <div class="swiper-button-next next-product next-product-hot"></div>
                <div class="swiper-button-prev prev-product prev-product-hot"></div>
            </div>
        </div>
        <div class="container-fluid" style="height:500px">
            <div class="title-invole-store">
                <span class="text-title">Sản phẩm mới</span>
                <span><a href="">Xem tất cả</a></span>
            </div>
            <div class="content-store">
                <div class="swiper-container SwiperStoreNew">
                    <div class="swiper-wrapper">
                        <?php for($i= 1;$i< 30; ++$i): ?>
                        <div class="swiper-slide">
                            <div class="owl-item">
                                <div class="item-info">
                                    <a href="#" class="team" title="Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML">
                                        <div class="img" style="height:250px;background-image: url(http://localhost:8081/myblog/public/haircare/images/stylist-<?php echo e(rand(1,5)); ?>.jpg);"></div>
                                        <span>Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML</span>
                                        <span>237,000₫</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <div class="swiper-button-next next-product next-product-new"></div>
                <div class="swiper-button-prev prev-product prev-product-new"></div>
            </div>
        </div>
        <div class="container-fluid" style="height:500px">
            <div class="title-invole-store">
                <span class="text-title">Sản phẩm mua nhiều</span>
                <span><a href="">Xem tất cả</a></span>
            </div>
            <div class="content-store">
                <div class="swiper-container SwiperStoreMany">
                    <div class="swiper-wrapper">
                        <?php for($i= 1;$i< 30; ++$i): ?>
                        <div class="swiper-slide">
                            <div class="owl-item">
                                <div class="item-info">
                                    <a href="#" class="team" title="Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML">
                                        <div class="img" style="height:250px;background-image: url(http://localhost:8081/myblog/public/haircare/images/stylist-<?php echo e(rand(1,5)); ?>.jpg);"></div>
                                        <span>Lăn Khử Mùi Ngăn Mồ Hôi Chuyên Biệt Etiaxil Deodorant Douceur 48h Roll-On 50ML</span>
                                        <span>237,000₫</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <div class="swiper-button-next next-product next-product-many"></div>
                <div class="swiper-button-prev prev-product prev-product-many"></div>
            </div>
        </div>
    </div>
</div>
<script>
    var SwiperBanner = new Swiper(".SwiperBanner", {
        effect: "fade",
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
    });
    var SwiperStoreHot = new Swiper(".SwiperStoreHot", {
        slidesPerView: 5,
        slidesPerGroup: 5,
        pagination: {
          el: ".swiper-pagination",
          type: "progressbar",
        },
        navigation: {
          nextEl: ".next-product-hot",
          prevEl: ".prev-product-hot",
        },
    });
    var SwiperStoreNew = new Swiper(".SwiperStoreNew", {
        slidesPerView: 5,
        slidesPerGroup: 5,
        pagination: {
          el: ".swiper-pagination",
          type: "progressbar",
        },
        navigation: {
          nextEl: ".next-product-new",
          prevEl: ".prev-product-new",
        },
    });
    var SwiperStoreMany = new Swiper(".SwiperStoreMany", {
        slidesPerView: 5,
        slidesPerGroup: 5,
        pagination: {
          el: ".swiper-pagination",
          type: "progressbar",
        },
        navigation: {
          nextEl: ".next-product-many",
          prevEl: ".prev-product-many",
        },
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('LayoutWeb/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\myblog\resources\views/Web/Store.blade.php ENDPATH**/ ?>
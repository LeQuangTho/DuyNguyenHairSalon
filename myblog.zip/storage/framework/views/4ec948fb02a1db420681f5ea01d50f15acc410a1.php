
<?php $__env->startSection('body'); ?>
    <div>
        Welcome Haircare
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('LayoutAdmin/MasterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\myblog\resources\views/Admin/HomeAdmin.blade.php ENDPATH**/ ?>
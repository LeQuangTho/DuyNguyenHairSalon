@extends('LayoutAdmin/MasterAdmin')
@section('body')
    <div>
        Welcome Haircare
    </div>
@endsection
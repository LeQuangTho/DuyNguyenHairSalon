<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SpeciesService extends Model
{
    protected $table = "speciesservice";
}
